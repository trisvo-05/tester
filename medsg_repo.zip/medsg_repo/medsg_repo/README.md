# MedSG-188K Kidney Triplet — TriScaTell Pipeline

Fine-tuning Qwen2.5-VL cho bài toán định vị thận CT bụng
bằng sequential triplet slices (z-k, z, z+k).

## Cấu trúc

```
notebooks/
  task1_build_triplets.ipynb    # Build 27,593 triplets từ MedSG-Bench
  task2_build_instruction.ipynb # Format instruction cho Qwen2.5-VL
  task3_eval_pipeline.ipynb     # Eval 5 metrics (IoU, vIoU3D, HD95...)
  task3b_run_inference.ipynb    # Generate predictions từ model
  task4_hardcase.ipynb          # Hard case re-classification
  task5_qc_autolabel.ipynb      # QC auto-labels (Cohen's κ)
  train_triscatell.ipynb        # Training (Generative Grounding)
  phase3_stats_sota.ipynb       # Significance testing + SOTA table

scripts/
  eval.py                       # Eval pipeline (CLI)
  qc_review.py                  # QC CLI tool
  fix_regression_head.py        # Hướng dẫn fix regression head bug

results/
  hardcase_recovery.csv         # 14 hard cases, 100% recovery
  significance_results.json     # Wilcoxon + Cohen's d
  qc_validate_report.json       # Instruction format validation

docs/
  manuscript_vi.tex             # Draft manuscript (tiếng Việt, arXiv)
```

## Thứ tự chạy

```
task1 → task2 → train_triscatell → task3b → task3 → task4 → task5 → phase3
```

## Key results (ckpt_full)

| Metric    | Value  |
|-----------|--------|
| vIoU3D    | 0.603  |
| mIoU 2D   | 0.468  |
| HD95      | 12.4px |
| Lat Acc   | 89.7%  |
| Hard case | 14/14 recovered |

## Kaggle dataset

`/kaggle/input/datasets/duythien1303/medsg-triplets/`
