#!/usr/bin/env python3
"""
qc_review.py — Quality Control CLI for Auto-label Verification
==============================================================
Medical reviewer verify presence_zk auto-labels trên 5% sample (~1098 triplets).

Usage:
  # Bước 1: Generate sample
  python qc_review.py sample \
      --train_jsonl /kaggle/working/data/medsg_triplets_v3/train.jsonl \
      --output_dir  /kaggle/working/qc \
      --seed 42

  # Bước 2: Review (CLI interactive — chạy terminal Kaggle hoặc local)
  python qc_review.py review \
      --qc_dir /kaggle/working/qc \
      --reviewer_id reviewer1

  # Bước 3: Compute Cohen's κ
  python qc_review.py kappa \
      --qc_dir /kaggle/working/qc

  # Bước 4 (nếu κ < 0.78): Tune IoU threshold
  python qc_review.py tune \
      --train_jsonl /kaggle/working/data/medsg_triplets_v3/train.jsonl \
      --qc_dir /kaggle/working/qc
"""

import argparse
import collections
import json
import math
import os
import random
import sys
import csv
from pathlib import Path
from typing import List, Optional, Tuple


# ── CONSTANTS ─────────────────────────────────────────────────
DEFAULT_SAMPLE_RATIO  = 0.05
DEFAULT_UNCERTAIN_PCT = 0.40   # 40% sample từ uncertain zone
IOU_THRESHOLD_DEFAULT = 0.3
IOU_UNCERTAIN_LO      = IOU_THRESHOLD_DEFAULT * 0.7   # 0.21
IOU_UNCERTAIN_HI      = IOU_THRESHOLD_DEFAULT * 1.3   # 0.39
KAPPA_TARGET          = 0.78
SEED                  = 42


# ── SAMPLING ──────────────────────────────────────────────────

def sample_for_qc(
    train_jsonl: Path,
    output_dir:  Path,
    seed:        int = SEED,
    ratio:       float = DEFAULT_SAMPLE_RATIO,
    uncertain_pct: float = DEFAULT_UNCERTAIN_PCT,
) -> Path:
    """
    Sample 5% triplets từ train set.
    Stratified: 40% từ uncertain zone (IoU 0.21–0.39), 60% confident.
    Output: qc/qc_sample.jsonl
    """
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(train_jsonl, encoding="utf-8") as f:
        train = [json.loads(l) for l in f if l.strip()]

    rng = random.Random(seed)
    n_total = max(1, int(len(train) * ratio))

    # Stratified split
    uncertain = [t for t in train if
                 t["presence_zk_minus"]["confidence"] == 0.5 or
                 t["presence_zk_plus"]["confidence"]  == 0.5]
    uncertain_set = set(id(t) for t in uncertain)
    confident = [t for t in train if id(t) not in uncertain_set]
    # Simpler split using index
    uncertain = [t for t in train if
                 IOU_UNCERTAIN_LO <= t["presence_zk_minus"]["iou"] <= IOU_UNCERTAIN_HI or
                 IOU_UNCERTAIN_LO <= t["presence_zk_plus"]["iou"]  <= IOU_UNCERTAIN_HI]
    confident = [t for t in train if t not in uncertain]

    n_unc  = min(len(uncertain), int(n_total * uncertain_pct))
    n_conf = min(len(confident), n_total - n_unc)

    sample_unc  = rng.sample(uncertain, n_unc)
    sample_conf = rng.sample(confident, n_conf)
    sample = sample_unc + sample_conf
    rng.shuffle(sample)

    # Add qc_id
    for i, t in enumerate(sample):
        t["qc_id"] = f"qc_{i+1:04d}"

    out_path = output_dir / "qc_sample.jsonl"
    with open(out_path, "w", encoding="utf-8") as f:
        for t in sample:
            f.write(json.dumps(t, ensure_ascii=False) + "\n")

    # Stats
    print(f"\n{'='*55}")
    print(f"  QC Sample Generated")
    print(f"{'='*55}")
    print(f"  Total train:        {len(train):,}")
    print(f"  5% sample:          {len(sample):,}")
    print(f"  └ Uncertain zone:   {n_unc} ({n_unc/len(sample)*100:.0f}%)")
    print(f"  └ Confident:        {n_conf} ({n_conf/len(sample)*100:.0f}%)")
    print(f"  Output:             {out_path}")
    print(f"{'='*55}\n")
    return out_path


# ── REVIEW CLI ────────────────────────────────────────────────

INSTRUCTIONS = """
╔══════════════════════════════════════════════════════════════╗
║         QC REVIEW — Presence Label Verification             ║
╠══════════════════════════════════════════════════════════════╣
║  Bạn sẽ thấy thông tin từng triplet CT slice.               ║
║  Auto-label: "yes" nếu IoU(bbox_z, bbox_z±k) > 0.3         ║
║                                                              ║
║  Câu hỏi: Kidney có XUẤT HIỆN trong slice z±k không?        ║
║                                                              ║
║  Phím tắt:                                                   ║
║    y  / Y  → yes (có kidney)                                 ║
║    n  / N  → no  (không có kidney)                           ║
║    s  / S  → skip (không chắc)                               ║
║    b  / B  → back (quay lại record trước)                    ║
║    q  / Q  → quit & save progress                            ║
║    ?       → hiển thị help này                               ║
╚══════════════════════════════════════════════════════════════╝
"""

def format_triplet_display(t: dict, idx: int, total: int) -> str:
    """Render triplet info cho terminal reviewer."""
    pm  = t["presence_zk_minus"]
    pp  = t["presence_zk_plus"]
    bbox = t.get("bbox_z", [])
    bbox_str = f"[{', '.join(f'{v:.3f}' for v in bbox)}]" if bbox else "N/A"

    # Hiển thị image paths (filename only)
    def fname(p): return Path(p).name[:60] if p else "N/A"

    lines = [
        f"\n{'─'*60}",
        f"  [{idx}/{total}]  QC ID: {t.get('qc_id','?')}",
        f"  Case:      {t.get('case_id','?')}",
        f"  Slice z:   {t.get('slice_id_z','?')}  |  k={t.get('k','?')}  |  lateral={t.get('laterality_label','?')}",
        f"{'─'*60}",
        f"  Images:",
        f"    z-k:  {fname(t['triplet_paths']['z_minus_k'])}",
        f"    z:    {fname(t['triplet_paths']['z'])}",
        f"    z+k:  {fname(t['triplet_paths']['z_plus_k'])}",
        f"{'─'*60}",
        f"  bbox_z (normalized): {bbox_str}",
        f"",
        f"  ┌── z-k (PREVIOUS slice z-{t.get('k','?')}) ──────────────────┐",
        f"  │  Auto-label: {pm['label'].upper():3}  |  IoU={pm['iou']:.4f}  |  conf={pm['confidence']:.2f}",
        f"  │  {'⚠ UNCERTAIN ZONE' if pm['confidence']==0.5 else '✓ confident'}",
        f"  └──────────────────────────────────────────────────────┘",
        f"",
        f"  ┌── z+k (NEXT slice z+{t.get('k','?')}) ──────────────────────┐",
        f"  │  Auto-label: {pp['label'].upper():3}  |  IoU={pp['iou']:.4f}  |  conf={pp['confidence']:.2f}",
        f"  │  {'⚠ UNCERTAIN ZONE' if pp['confidence']==0.5 else '✓ confident'}",
        f"  └──────────────────────────────────────────────────────┘",
        f"",
    ]
    return "\n".join(lines)


def run_review(
    qc_dir:      Path,
    reviewer_id: str,
) -> Path:
    """Interactive CLI review session."""
    sample_path  = qc_dir / "qc_sample.jsonl"
    review_path  = qc_dir / f"review_{reviewer_id}.jsonl"

    if not sample_path.exists():
        print(f"ERROR: {sample_path} not found. Run 'sample' step first.")
        sys.exit(1)

    with open(sample_path, encoding="utf-8") as f:
        samples = [json.loads(l) for l in f if l.strip()]

    # Load existing progress
    completed = {}
    if review_path.exists():
        with open(review_path, encoding="utf-8") as f:
            for line in f:
                r = json.loads(line)
                completed[r["qc_id"]] = r

    pending = [s for s in samples if s["qc_id"] not in completed]

    print(INSTRUCTIONS)
    print(f"  Reviewer: {reviewer_id}")
    print(f"  Progress: {len(completed)}/{len(samples)} completed")
    print(f"  Remaining: {len(pending)}")
    print()

    if not pending:
        print("  All samples reviewed! Run 'kappa' to compute metrics.")
        return review_path

    history = []
    i = 0
    while i < len(pending):
        t     = pending[i]
        total = len(samples)
        done  = len(completed) + i

        print(format_triplet_display(t, done + 1, total))

        # Q1: z-k presence
        print(f"  Q1: Is kidney PRESENT in the PREVIOUS slice (z-{t.get('k','?')})? [y/n/s/b/q/?]")
        ans_minus = _get_input()
        if ans_minus == "q":
            _save_progress(completed, review_path)
            print(f"\n  Progress saved ({len(completed)} reviews). Resume with same command.")
            return review_path
        if ans_minus == "b" and history:
            prev_qc_id = history.pop()
            if prev_qc_id in completed:
                del completed[prev_qc_id]
            i -= 1
            continue
        if ans_minus == "?":
            print(INSTRUCTIONS); continue

        # Q2: z+k presence (only if Q1 answered)
        if ans_minus in ("y", "n", "s"):
            print(f"  Q2: Is kidney PRESENT in the NEXT slice (z+{t.get('k','?')})? [y/n/s/b/q/?]")
            ans_plus = _get_input()
            if ans_plus == "q":
                _save_progress(completed, review_path)
                print(f"\n  Progress saved ({len(completed)} reviews).")
                return review_path
            if ans_plus == "b":
                continue  # redo this record

            # Save review
            review_rec = {
                "qc_id":             t["qc_id"],
                "case_id":           t.get("case_id"),
                "slice_id_z":        t.get("slice_id_z"),
                "k":                 t.get("k"),
                "reviewer_id":       reviewer_id,
                # Auto labels
                "auto_minus":        t["presence_zk_minus"]["label"],
                "auto_plus":         t["presence_zk_plus"]["label"],
                "auto_iou_minus":    t["presence_zk_minus"]["iou"],
                "auto_iou_plus":     t["presence_zk_plus"]["iou"],
                "auto_conf_minus":   t["presence_zk_minus"]["confidence"],
                "auto_conf_plus":    t["presence_zk_plus"]["confidence"],
                # Human labels
                "human_minus":       ans_minus,   # y/n/s
                "human_plus":        ans_plus,
                # Agreement
                "agree_minus":       _agree(t["presence_zk_minus"]["label"], ans_minus),
                "agree_plus":        _agree(t["presence_zk_plus"]["label"], ans_plus),
            }
            completed[t["qc_id"]] = review_rec
            history.append(t["qc_id"])

            # Live feedback
            agree_m = "✓" if review_rec["agree_minus"] == "agree" else ("? skip" if ans_minus=="s" else "✗ DISAGREE")
            agree_p = "✓" if review_rec["agree_plus"]  == "agree" else ("? skip" if ans_plus =="s" else "✗ DISAGREE")
            print(f"  Saved  →  z-k: {agree_m}  |  z+k: {agree_p}")

            # Auto-save every 50
            if len(completed) % 50 == 0:
                _save_progress(completed, review_path)
                print(f"  [Auto-saved at {len(completed)} reviews]")

        i += 1

    _save_progress(completed, review_path)
    print(f"\n{'='*55}")
    print(f"  Review complete! {len(completed)}/{len(samples)} samples reviewed.")
    print(f"  Saved: {review_path}")
    print(f"  Next: python qc_review.py kappa --qc_dir {qc_dir}")
    print(f"{'='*55}\n")
    return review_path


def _get_input() -> str:
    while True:
        try:
            ans = input("  > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return "q"
        if ans in ("y","n","s","b","q","?"):
            return ans
        print(f"  Invalid input '{ans}'. Use y/n/s/b/q/?")


def _agree(auto: str, human: str) -> str:
    if human == "s": return "skip"
    auto_yn = auto  # 'yes'/'no'
    human_yn = "yes" if human == "y" else "no"
    return "agree" if auto_yn == human_yn else "disagree"


def _save_progress(completed: dict, path: Path) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for rec in completed.values():
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


# ── COHEN'S KAPPA ─────────────────────────────────────────────

def compute_kappa(qc_dir: Path) -> dict:
    """
    Compute Cohen's κ giữa auto-label và human label.
    Aggregated across all reviewers và cả 2 positions (minus + plus).
    Output: results/kappa_report.json + kappa_errors.csv
    """
    review_files = list(qc_dir.glob("review_*.jsonl"))
    if not review_files:
        print("ERROR: No review files found. Run 'review' step first.")
        sys.exit(1)

    all_reviews = []
    for rf in review_files:
        with open(rf, encoding="utf-8") as f:
            for line in f:
                all_reviews.append(json.loads(line))

    print(f"\nLoaded {len(all_reviews)} reviews from {len(review_files)} reviewer(s)")

    # Collect (auto, human) pairs — skip 's' (skip)
    pairs_minus = []
    pairs_plus  = []
    errors      = []

    for r in all_reviews:
        # z-k
        if r["human_minus"] != "s":
            a = 1 if r["auto_minus"] == "yes" else 0
            h = 1 if r["human_minus"] == "y"  else 0
            pairs_minus.append((a, h))
            if a != h:
                errors.append({
                    "qc_id":      r["qc_id"],
                    "case_id":    r["case_id"],
                    "position":   "minus",
                    "auto_label": r["auto_minus"],
                    "human_label":r["human_minus"],
                    "iou":        r["auto_iou_minus"],
                    "confidence": r["auto_conf_minus"],
                    "reviewer":   r["reviewer_id"],
                })
        # z+k
        if r["human_plus"] != "s":
            a = 1 if r["auto_plus"] == "yes" else 0
            h = 1 if r["human_plus"] == "y"  else 0
            pairs_plus.append((a, h))
            if a != h:
                errors.append({
                    "qc_id":      r["qc_id"],
                    "case_id":    r["case_id"],
                    "position":   "plus",
                    "auto_label": r["auto_plus"],
                    "human_label":r["human_plus"],
                    "iou":        r["auto_iou_plus"],
                    "confidence": r["auto_conf_plus"],
                    "reviewer":   r["reviewer_id"],
                })

    def cohen_kappa(pairs):
        if not pairs: return float("nan"), {}
        n   = len(pairs)
        a1  = sum(1 for a,h in pairs if a==1)
        h1  = sum(1 for a,h in pairs if h==1)
        po  = sum(1 for a,h in pairs if a==h) / n
        pe  = (a1/n)*(h1/n) + (1-a1/n)*(1-h1/n)
        k   = (po - pe) / (1 - pe) if (1 - pe) > 0 else 1.0
        # Confusion matrix
        cm = {"TP":0,"FP":0,"FN":0,"TN":0}
        for a,h in pairs:
            if   a==1 and h==1: cm["TP"]+=1
            elif a==1 and h==0: cm["FP"]+=1
            elif a==0 and h==1: cm["FN"]+=1
            else:               cm["TN"]+=1
        return round(k, 4), {"po": round(po,4), "pe": round(pe,4), **cm, "n": n}

    kappa_m, stats_m = cohen_kappa(pairs_minus)
    kappa_p, stats_p = cohen_kappa(pairs_plus)

    # Combined
    all_pairs = pairs_minus + pairs_plus
    kappa_combined, stats_combined = cohen_kappa(all_pairs)

    # Kappa by IoU bin (để tìm problematic zones)
    bins = [(0,0.1),(0.1,0.2),(0.2,0.3),(0.3,0.4),(0.4,0.6),(0.6,1.01)]
    kappa_by_iou = {}
    for lo,hi in bins:
        bin_pairs = []
        for r in all_reviews:
            for pos, iou_key, auto_key, human_key in [
                ("minus","auto_iou_minus","auto_minus","human_minus"),
                ("plus", "auto_iou_plus", "auto_plus", "human_plus"),
            ]:
                iou = r[iou_key]
                if lo<=iou<hi and r[human_key]!="s":
                    a = 1 if r[auto_key]=="yes" else 0
                    h = 1 if r[human_key]=="y"  else 0
                    bin_pairs.append((a,h))
        k,_ = cohen_kappa(bin_pairs)
        a1_bin = sum(1 for a,h in bin_pairs if a==1)
        kappa_by_iou[f"{lo:.1f}-{hi:.1f}"] = {"kappa": k if a1_bin not in (0, len(bin_pairs)) else None, "n": len(bin_pairs), "note": "skewed_marginal" if a1_bin in (0,len(bin_pairs)) else "ok"}

    # Build report
    report = {
        "n_reviews":         len(all_reviews),
        "n_reviewers":       len(review_files),
        "n_pairs_minus":     len(pairs_minus),
        "n_pairs_plus":      len(pairs_plus),
        "kappa_minus":       kappa_m,
        "kappa_plus":        kappa_p,
        "kappa_combined":    kappa_combined,
        "target_kappa":      KAPPA_TARGET,
        "kappa_ok":          kappa_combined >= KAPPA_TARGET,
        "stats_minus":       stats_m,
        "stats_plus":        stats_p,
        "stats_combined":    stats_combined,
        "kappa_by_iou_bin":  kappa_by_iou,
        "n_errors":          len(errors),
        "error_rate":        round(len(errors)/max(1,len(all_pairs)),4),
    }

    # Print summary
    print(f"\n{'='*55}")
    print(f"  Cohen's Kappa Report")
    print(f"{'='*55}")
    print(f"  Reviews:   {len(all_reviews)}  ({len(review_files)} reviewer(s))")
    print(f"  Pairs:     {len(all_pairs)} (z-k: {len(pairs_minus)}, z+k: {len(pairs_plus)})")
    print()
    print(f"  κ (z-k):      {kappa_m:.4f}")
    print(f"  κ (z+k):      {kappa_p:.4f}")
    print(f"  κ (combined): {kappa_combined:.4f}  {'✓ OK' if kappa_combined>=KAPPA_TARGET else f'⚠ BELOW {KAPPA_TARGET}'}")
    print(f"  Target:       {KAPPA_TARGET}")
    print()
    print(f"  Confusion (combined):")
    cm = stats_combined
    print(f"    TP={cm['TP']} FP={cm['FP']} FN={cm['FN']} TN={cm['TN']}")
    print(f"    Precision={cm['TP']/max(1,cm['TP']+cm['FP']):.3f}  "
          f"Recall={cm['TP']/max(1,cm['TP']+cm['FN']):.3f}")
    print()
    print(f"  κ by IoU bin:")
    for bin_range, bstats in kappa_by_iou.items():
        k_val = bstats['kappa']
        if k_val is None:
            print(f"    IoU {bin_range}: κ=N/A (skewed marginal)  n={bstats['n']}")
        else:
            flag = " ← problematic" if k_val < 0.6 else ""
            print(f"    IoU {bin_range}: κ={k_val:.4f}  n={bstats['n']}{flag}")
    print()
    print(f"  Auto-label errors: {len(errors)} ({report['error_rate']*100:.1f}%)")
    if not report["kappa_ok"]:
        print(f"\n  ⚠ κ < {KAPPA_TARGET} — Run 'tune' to find optimal IoU threshold")
    print(f"{'='*55}\n")

    # Save report
    report_path = qc_dir / "kappa_report.json"
    with open(report_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"  Report: {report_path}")

    # Save errors CSV
    if errors:
        errors_path = qc_dir / "kappa_errors.csv"
        with open(errors_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(errors[0].keys()))
            w.writeheader(); w.writerows(errors)
        print(f"  Errors: {errors_path}  ({len(errors)} rows)")

    return report


# ── THRESHOLD TUNING ──────────────────────────────────────────

def tune_threshold(train_jsonl: Path, qc_dir: Path) -> dict:
    """
    Nếu κ < 0.78: tìm IoU threshold tối ưu bằng grid search trên human labels.
    Output: kappa_tune_report.json với recommended_threshold.
    """
    review_files = list(qc_dir.glob("review_*.jsonl"))
    if not review_files:
        print("ERROR: No review files found.")
        sys.exit(1)

    # Load all human labels with IoU
    human_data = []
    for rf in review_files:
        with open(rf) as f:
            for line in f:
                r = json.loads(line)
                for pos, iou_key, auto_key, human_key in [
                    ("minus","auto_iou_minus","auto_minus","human_minus"),
                    ("plus", "auto_iou_plus", "auto_plus", "human_plus"),
                ]:
                    if r[human_key] != "s":
                        human_data.append({
                            "iou":         r[iou_key],
                            "human_label": 1 if r[human_key]=="y" else 0,
                        })

    if not human_data:
        print("No valid human labels found.")
        return {}

    # Grid search: threshold từ 0.1 đến 0.6
    best_kappa = -1
    best_thresh = IOU_THRESHOLD_DEFAULT
    results = []

    for thresh in [i/100 for i in range(10, 65, 5)]:
        pairs = []
        for d in human_data:
            auto = 1 if d["iou"] >= thresh else 0
            human = d["human_label"]
            pairs.append((auto, human))

        n = len(pairs)
        a1 = sum(1 for a,h in pairs if a==1)
        h1 = sum(1 for a,h in pairs if h==1)
        po = sum(1 for a,h in pairs if a==h) / n
        pe = (a1/n)*(h1/n) + (1-a1/n)*(1-h1/n)
        k  = (po-pe)/(1-pe) if (1-pe)>0 else 1.0
        results.append({"threshold":thresh, "kappa":round(k,4), "po":round(po,4)})
        if k > best_kappa:
            best_kappa = k
            best_thresh = thresh

    # Print
    print(f"\n{'='*55}")
    print(f"  IoU Threshold Tuning")
    print(f"{'='*55}")
    print(f"  {'Threshold':>10} {'Kappa':>8} {'Po':>8}")
    print(f"  {'─'*30}")
    for r in results:
        flag = " ← BEST" if r["threshold"]==best_thresh else \
               (" ← current" if abs(r["threshold"]-IOU_THRESHOLD_DEFAULT)<0.01 else "")
        print(f"  {r['threshold']:>10.2f} {r['kappa']:>8.4f} {r['po']:>8.4f}{flag}")
    print()
    print(f"  Recommended threshold: {best_thresh:.2f}  (κ={best_kappa:.4f})")
    if best_kappa >= KAPPA_TARGET:
        print(f"  ✓ κ ≥ {KAPPA_TARGET} achievable with threshold={best_thresh:.2f}")
        print(f"  → Rebuild dataset với IOU_THRESHOLD={best_thresh:.2f}")
    else:
        print(f"  ⚠ κ still below {KAPPA_TARGET} at any threshold")
        print(f"  → Cần thêm reviewers hoặc improve bbox quality")
    print(f"{'='*55}\n")

    tune_report = {
        "n_human_labels":     len(human_data),
        "grid_search":        results,
        "best_threshold":     best_thresh,
        "best_kappa":         round(best_kappa, 4),
        "current_threshold":  IOU_THRESHOLD_DEFAULT,
        "current_kappa_est":  next((r["kappa"] for r in results
                               if abs(r["threshold"]-IOU_THRESHOLD_DEFAULT)<0.01), None),
        "rebuild_needed":     best_thresh != IOU_THRESHOLD_DEFAULT,
        "target_kappa":       KAPPA_TARGET,
    }
    tune_path = qc_dir / "kappa_tune_report.json"
    with open(tune_path, "w") as f:
        json.dump(tune_report, f, indent=2)
    print(f"  Tune report: {tune_path}")
    return tune_report


# ── MAIN ──────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="QC Review CLI for auto-label verification"
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # sample
    p_sample = sub.add_parser("sample", help="Generate QC sample")
    p_sample.add_argument("--train_jsonl", required=True)
    p_sample.add_argument("--output_dir",  required=True)
    p_sample.add_argument("--seed",        type=int, default=SEED)
    p_sample.add_argument("--ratio",       type=float, default=DEFAULT_SAMPLE_RATIO)

    # review
    p_review = sub.add_parser("review", help="Interactive CLI review")
    p_review.add_argument("--qc_dir",      required=True)
    p_review.add_argument("--reviewer_id", required=True,
                          help="Unique reviewer ID, e.g. 'reviewer1' or 'prof_nguyen'")

    # kappa
    p_kappa = sub.add_parser("kappa", help="Compute Cohen's kappa")
    p_kappa.add_argument("--qc_dir", required=True)

    # tune
    p_tune = sub.add_parser("tune", help="Tune IoU threshold if kappa < target")
    p_tune.add_argument("--train_jsonl", required=True)
    p_tune.add_argument("--qc_dir",     required=True)

    args = parser.parse_args()

    if args.command == "sample":
        sample_for_qc(
            Path(args.train_jsonl), Path(args.output_dir),
            seed=args.seed, ratio=args.ratio
        )
    elif args.command == "review":
        run_review(Path(args.qc_dir), args.reviewer_id)
    elif args.command == "kappa":
        compute_kappa(Path(args.qc_dir))
    elif args.command == "tune":
        tune_threshold(Path(args.train_jsonl), Path(args.qc_dir))


if __name__ == "__main__":
    main()
