"""
fix_regression_head.py
======================
Hướng dẫn fix bug: Regression Head xung đột với Generative Grounding
trong Qwen2.5-VL fine-tuning cho TriScaTell.

BUG:
    Model có 2 regression heads thừa:
        self.bbox_head       = nn.Linear(llm_dim, 4)   # dự đoán [x1,y1,x2,y2]
        self.laterality_head = nn.Linear(llm_dim, 2)   # dự đoán [left, right]

    Trong khi data đã format theo Generative Grounding:
        A1: "The kidney is visible on the left side."
        A2: "Center slice bounding box: <|box_start|>(111,46),(149,123)<|box_end|>.
             Previous slice (z-1): kidney not present.
             Next slice (z+1): kidney present."

    → Model không biết nên học generate text hay trả số float từ head
    → Loss không giảm, bbox loạn xà ngầu

GIẢI PHÁP: Xóa 2 heads, dùng thuần Generative Grounding (CrossEntropy LM loss)
"""

# ══════════════════════════════════════════════════════════════════
# TRƯỚC (SAI) — Custom model wrapper với regression heads
# ══════════════════════════════════════════════════════════════════

class TriScaTellModel_WRONG:
    """❌ ĐỪNG LÀM NHƯ NÀY"""

    def __init__(self, base_model, llm_dim=3584):
        self.model = base_model

        # ❌ 2 heads thừa — xung đột với text generation
        self.bbox_head       = None  # nn.Linear(llm_dim, 4)
        self.laterality_head = None  # nn.Linear(llm_dim, 2)

    def forward(self, input_ids, attention_mask, labels, pixel_values, **kwargs):
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            pixel_values=pixel_values,
            **kwargs,
        )
        # ❌ Dùng hidden state cuối để predict bbox — không match với text labels
        last_hidden = outputs.last_hidden_state[:, -1, :]
        bbox_pred = self.bbox_head(last_hidden)         # [B, 4]
        lat_pred  = self.laterality_head(last_hidden)   # [B, 2]

        # ❌ Loss hỗn hợp — model bị "lạc lối"
        lm_loss   = outputs.loss
        l1_loss   = None  # F.l1_loss(bbox_pred, bbox_targets)
        giou_loss = None  # generalized_iou_loss(bbox_pred, bbox_targets)
        lat_loss  = None  # F.cross_entropy(lat_pred, lat_targets)

        # ❌ Tổng loss mâu thuẫn: LM học generate text, heads học predict số
        total_loss = lm_loss + 0.5 * l1_loss + 0.5 * giou_loss + 0.3 * lat_loss
        return total_loss


# ══════════════════════════════════════════════════════════════════
# SAU (ĐÚNG) — Thuần Generative Grounding, không có heads
# ══════════════════════════════════════════════════════════════════

def load_model_correct(model_path: str):
    """
    ✅ Load Qwen2.5-VL NGUYÊN BẢN, không thêm head nào.
    Fine-tune bằng standard Causal LM loss (CrossEntropy trên tokens).
    """
    from transformers import Qwen2_5_VLForConditionalGeneration, AutoProcessor
    from peft import LoraConfig, get_peft_model, TaskType

    # Load base model — KHÔNG thêm linear layers
    model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
        model_path,
        torch_dtype="bfloat16",
        device_map="auto",
        trust_remote_code=True,
    )

    # ✅ Chỉ dùng LoRA để fine-tune — không modify architecture
    lora_config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=16,
        lora_alpha=32,
        lora_dropout=0.05,
        target_modules=[
            "q_proj", "k_proj", "v_proj", "o_proj",
            "gate_proj", "up_proj", "down_proj",
        ],
        bias="none",
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    processor = AutoProcessor.from_pretrained(model_path, trust_remote_code=True)
    return model, processor


# ══════════════════════════════════════════════════════════════════
# TRAINING LOOP ĐÚNG — Chỉ dùng model.loss (CrossEntropy LM)
# ══════════════════════════════════════════════════════════════════

def training_step_correct(model, batch):
    """
    ✅ Standard Causal LM training step.
    - Labels = token ids của answer (A1 + A2)
    - Tokens thuộc phần prompt/question được mask bằng -100
    - Loss = CrossEntropy chỉ trên answer tokens
    """
    outputs = model(
        input_ids      = batch["input_ids"],
        attention_mask = batch["attention_mask"],
        pixel_values   = batch["pixel_values"],
        image_grid_thw = batch.get("image_grid_thw"),
        labels         = batch["labels"],  # -100 cho prompt tokens
    )

    # ✅ Chỉ 1 loss duy nhất — model tự học generate bbox text
    loss = outputs.loss  # CrossEntropy trên answer tokens

    # Không cần l1_loss, giou_loss, hay lat_loss nữa
    return loss


# ══════════════════════════════════════════════════════════════════
# DATA COLLATOR — Cách mask labels đúng
# ══════════════════════════════════════════════════════════════════

def collate_fn_correct(samples, processor, device):
    """
    ✅ Mask labels: -100 cho system+user tokens, giữ nguyên assistant tokens.
    CrossEntropy chỉ tính trên assistant tokens → model học generate A1 + A2.
    """
    import torch

    IGNORE_INDEX = -100  # PyTorch convention: bỏ qua khi tính loss

    batch_input_ids = []
    batch_labels    = []
    batch_images    = []

    for s in samples:
        # Build conversation
        messages = s["conversations"]  # [system, user, assistant, user, assistant]

        # Tokenize full conversation
        text = processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=False
        )
        inputs = processor(
            text=[text],
            images=s["images"],
            return_tensors="pt",
            padding=True,
        )
        input_ids = inputs["input_ids"][0]

        # Build labels: mask everything trước assistant tokens
        labels = input_ids.clone()

        # Tìm vị trí các assistant turns và mask phần còn lại
        # Cách đơn giản: tìm <|im_start|>assistant tokens
        IM_START_ASSISTANT = processor.tokenizer.encode(
            "<|im_start|>assistant\n", add_special_tokens=False
        )
        IM_END = processor.tokenizer.encode("<|im_end|>", add_special_tokens=False)

        in_assistant = False
        i = 0
        while i < len(labels):
            # Check if starts assistant turn
            if input_ids[i:i+len(IM_START_ASSISTANT)].tolist() == IM_START_ASSISTANT:
                # Mask the im_start|>assistant\n tokens too
                labels[i:i+len(IM_START_ASSISTANT)] = IGNORE_INDEX
                i += len(IM_START_ASSISTANT)
                in_assistant = True
                continue
            # Check if ends turn
            if in_assistant and input_ids[i:i+len(IM_END)].tolist() == IM_END:
                labels[i:i+len(IM_END)] = IGNORE_INDEX
                i += len(IM_END)
                in_assistant = False
                continue
            # Mask non-assistant tokens
            if not in_assistant:
                labels[i] = IGNORE_INDEX
            i += 1

        batch_input_ids.append(input_ids)
        batch_labels.append(labels)
        if "pixel_values" in inputs:
            batch_images.append(inputs["pixel_values"])

    return {
        "input_ids":      torch.stack(batch_input_ids).to(device),
        "labels":         torch.stack(batch_labels).to(device),
        "attention_mask": (torch.stack(batch_input_ids) != processor.tokenizer.pad_token_id).to(device),
        "pixel_values":   torch.cat(batch_images).to(device) if batch_images else None,
    }


# ══════════════════════════════════════════════════════════════════
# DÙNG LLAMA-FACTORY (KHUYẾN NGHỊ) — Không cần viết training loop
# ══════════════════════════════════════════════════════════════════

LLAMAFACTORY_CONFIG = """
# dataset_info.json — đăng ký dataset
{
  "medsg_kidney_triplet": {
    "file_name": "instruction_train.json",
    "formatting": "sharegpt",
    "columns": {
      "messages": "conversations",
      "images":   "images"
    },
    "tags": {
      "role_tag":    "role",
      "content_tag": "content",
      "user_tag":    "user",
      "assistant_tag": "assistant",
      "system_tag":  "system"
    }
  }
}

# train_config.yaml — LLaMA-Factory SFT
model_name_or_path: Qwen/Qwen2.5-VL-7B-Instruct
stage: sft                    # ✅ Standard SFT — CrossEntropy loss tự động
do_train: true
finetuning_type: lora         # ✅ LoRA, không modify architecture

dataset: medsg_kidney_triplet
template: qwen2_vl            # ✅ Qwen2.5-VL chat template
cutoff_len: 8192
max_samples: 22000

# LoRA config
lora_rank: 16
lora_alpha: 32
lora_dropout: 0.05
lora_target: q_proj,k_proj,v_proj,o_proj,gate_proj,up_proj,down_proj

# Training
per_device_train_batch_size: 2
gradient_accumulation_steps: 8
learning_rate: 5.0e-5
num_train_epochs: 3
lr_scheduler_type: cosine
warmup_ratio: 0.05

# ✅ Không cần gì thêm — LLaMA-Factory tự handle:
#   - Image encoding (pixel_values)
#   - Label masking (-100 cho prompt tokens)
#   - CrossEntropy loss trên assistant tokens
#   - Bbox text "<|box_start|>...<|box_end|>" được học tự nhiên
"""

LLAMAFACTORY_RUN = """
# Chạy training:
llamafactory-cli train train_config.yaml

# Hoặc với ms-swift:
swift sft \\
    --model_type qwen2_5-vl-7b-instruct \\
    --dataset medsg_kidney_triplet \\
    --sft_type lora \\
    --output_dir output/triscatell_full \\
    --num_train_epochs 3 \\
    --learning_rate 5e-5 \\
    --lora_rank 16
"""


# ══════════════════════════════════════════════════════════════════
# CHECKLIST — Xác nhận đã fix xong
# ══════════════════════════════════════════════════════════════════

CHECKLIST = """
✅ Checklist sau khi fix:

1. [ ] Xóa self.bbox_head = nn.Linear(...) khỏi model class
2. [ ] Xóa self.laterality_head = nn.Linear(...) khỏi model class
3. [ ] Xóa l1_loss, giou_loss, lat_loss khỏi training loop
4. [ ] Chỉ dùng loss = outputs.loss (CrossEntropy từ Qwen2VL)
5. [ ] Labels phải mask prompt tokens bằng -100
6. [ ] Verify: model.generate() ra text có <|box_start|>...<|box_end|>
7. [ ] Verify: training loss giảm đều (không dao động loạn)

Expected training loss curve:
    Epoch 1: ~2.5 → ~1.8
    Epoch 2: ~1.8 → ~1.2
    Epoch 3: ~1.2 → ~0.8

Nếu loss không giảm hoặc >3.0 sau epoch 1 → kiểm tra lại label masking.
"""

if __name__ == "__main__":
    print("Fix guide for TriScaTell regression head bug")
    print("=" * 60)
    print(CHECKLIST)
    print()
    print("LLaMA-Factory config:")
    print(LLAMAFACTORY_CONFIG)
    print()
    print("Run command:")
    print(LLAMAFACTORY_RUN)
