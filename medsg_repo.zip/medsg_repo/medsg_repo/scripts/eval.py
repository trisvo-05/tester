#!/usr/bin/env python3
"""
eval/triscatell_eval.py  (v2 — fixed)
======================================
Evaluation pipeline cho MedSG Kidney Sequential Triplet model.

Fixes so với v1:
  FIX 1: Presence accuracy — parse từ raw pred_a2 text thay vì dùng GT label.
          Per_sample giờ ghi thêm pred_pres_correct_minus/plus.
  FIX 2: Laterality regression flag — đánh dấu cases model bị confuse
          left↔right khi IoU cao (bbox đúng nhưng laterality sai).

5 metrics:
  1. Mean IoU 2D (slice z)  + 95% CI bootstrap n=1000
  2. Avg Center Distance (px)
  3. Laterality Accuracy  [fixed: per sample + regression flag]
  4. 3D vIoU (volumetric IoU) — PRIMARY metric
  5. HD95 (Hausdorff Distance 95th percentile) per case
  + Presence Accuracy (zk_minus, zk_plus)  [NEW — fixed]

Prediction JSON format:
  [{"id": "<sample_id>",
    "pred_a1": "The kidney is visible on the left side.",
    "pred_a2": "Center slice bounding box: <|box_start|>(x1,y1),(x2,y2)<|box_end|>.
                Previous slice (z-1): kidney present.
                Next slice (z+1): kidney not present."},
   ...]

Usage:
  python eval/triscatell_eval.py \
      --test_json /kaggle/working/data/medsg_triplets_v3/instruction_test.json \
      --pred_jsons /kaggle/working/results/pred_ckpt{1..5}.json \
      --ckpt_names ckpt_base ckpt_lora ckpt_full ckpt_aug ckpt_best \
      --workers 5 \
      --output_dir /kaggle/working/results

  # Dry-run:
  python eval/triscatell_eval.py \
      --test_json /path/to/instruction_test.json \
      --mock --output_dir results/
"""

import argparse, collections, csv, json, math, multiprocessing
import os, random, re, time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.spatial.distance import cdist

# ── CONSTANTS ────────────────────────────────────────────────
IMG_SIZE    = 512
BOOTSTRAP_N = 1000
SEED        = 42
PAT_BBOX    = re.compile(r"<\|box_start\|>\((\d+),(\d+)\),\((\d+),(\d+)\)<\|box_end\|>")

# ── FIX 1: Presence parser patterns ─────────────────────────
# Model outputs: "Previous slice (z-1): kidney present."
#             or "Previous slice (z-1): kidney not present."
#             or "Previous slice (z-1): kidney not present (uncertain)."
PAT_PRES_MINUS = re.compile(
    r"[Pp]revious\s+slice[^:]*:\s*kidney\s+(not\s+present|present)", re.I
)
PAT_PRES_PLUS  = re.compile(
    r"[Nn]ext\s+slice[^:]*:\s*kidney\s+(not\s+present|present)", re.I
)


# ── PARSING ──────────────────────────────────────────────────

def parse_bbox_pixel(text: str) -> Optional[List[int]]:
    """Parse '<|box_start|>(x1,y1),(x2,y2)<|box_end|>' → [x1,y1,x2,y2] pixel."""
    m = PAT_BBOX.search(text or "")
    if not m: return None
    x1,y1,x2,y2 = int(m.group(1)),int(m.group(2)),int(m.group(3)),int(m.group(4))
    x1,x2 = max(0,x1), min(IMG_SIZE,x2)
    y1,y2 = max(0,y1), min(IMG_SIZE,y2)
    return [x1,y1,x2,y2] if x2>x1 and y2>y1 else None


def parse_bbox_norm(norm: Optional[list]) -> Optional[List[int]]:
    """Normalized [0,1] → pixel coords."""
    if not norm or len(norm)!=4: return None
    x1=max(0,min(IMG_SIZE-1,round(norm[0]*IMG_SIZE)))
    y1=max(0,min(IMG_SIZE-1,round(norm[1]*IMG_SIZE)))
    x2=max(0,min(IMG_SIZE,  round(norm[2]*IMG_SIZE)))
    y2=max(0,min(IMG_SIZE,  round(norm[3]*IMG_SIZE)))
    if x2<=x1: x2=x1+1
    if y2<=y1: y2=y1+1
    return [x1,y1,x2,y2]


def parse_laterality(text: str) -> str:
    t = (text or "").lower()
    if "both" in t or "bilateral" in t: return "bilateral"
    if "left"  in t and "right" not in t: return "left"
    if "right" in t and "left"  not in t: return "right"
    return "unknown"


def parse_presence(text: str, pattern: re.Pattern) -> Optional[str]:
    """
    FIX 1: Parse presence label từ raw model output text.
    Returns 'yes'/'no'/None (None = model không output presence).
    """
    m = pattern.search(text or "")
    if not m: return None
    return "yes" if "not" not in m.group(1).lower() else "no"


# ── METRIC 1: IoU 2D + Bootstrap CI ─────────────────────────

def iou_2d(a: Optional[List[int]], b: Optional[List[int]]) -> float:
    if not a or not b: return 0.0
    ix1,iy1 = max(a[0],b[0]), max(a[1],b[1])
    ix2,iy2 = min(a[2],b[2]), min(a[3],b[3])
    inter = max(0,ix2-ix1)*max(0,iy2-iy1)
    if inter==0: return 0.0
    union = (a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter
    return inter/union if union>0 else 0.0


def bootstrap_ci(values: List[float], n: int=BOOTSTRAP_N, seed: int=SEED) -> Tuple[float,float]:
    arr = np.array([v for v in values if not math.isnan(v)])
    if len(arr)==0: return float("nan"), float("nan")
    rng   = np.random.default_rng(seed)
    means = [np.mean(rng.choice(arr,len(arr),replace=True)) for _ in range(n)]
    return (round(float(np.percentile(means, 2.5)),4),
            round(float(np.percentile(means,97.5)),4))


# ── METRIC 2: Center Distance ────────────────────────────────

def center_dist_px(a: Optional[List[int]], b: Optional[List[int]]) -> float:
    if not a or not b: return float("nan")
    ca = ((a[0]+a[2])/2, (a[1]+a[3])/2)
    cb = ((b[0]+b[2])/2, (b[1]+b[3])/2)
    return math.sqrt((ca[0]-cb[0])**2+(ca[1]-cb[1])**2)


# ── METRIC 4: 3D vIoU ────────────────────────────────────────

def viou_3d(gt_map: Dict, pred_map: Dict, thickness: float=1.0) -> float:
    """
    PRIMARY METRIC: Volumetric IoU.
    Stack predicted bboxes qua chuỗi slice → 3D intersection/union.
    gt_map / pred_map: {slice_id_z -> bbox_pixel or None}
    """
    all_z = sorted(set(gt_map)|set(pred_map))
    inter_vol = union_vol = 0.0
    for z in all_z:
        gt   = gt_map.get(z)
        pred = pred_map.get(z)
        ag = (gt[2]-gt[0])*(gt[3]-gt[1])     if gt   else 0.0
        ap = (pred[2]-pred[0])*(pred[3]-pred[1]) if pred else 0.0
        if gt and pred:
            ix1,iy1=max(gt[0],pred[0]),max(gt[1],pred[1])
            ix2,iy2=min(gt[2],pred[2]),min(gt[3],pred[3])
            inter_2d=max(0,ix2-ix1)*max(0,iy2-iy1)
        else:
            inter_2d=0.0
        inter_vol += inter_2d           * thickness
        union_vol += (ag+ap-inter_2d)  * thickness
    return inter_vol/union_vol if union_vol>0 else 0.0


# ── METRIC 5: HD95 ───────────────────────────────────────────

def _bbox_pts(bbox: List[int], n: int=32) -> np.ndarray:
    x1,y1,x2,y2=bbox; t=np.linspace(0,1,n,endpoint=False)
    return np.vstack([
        np.column_stack([x1+t*(x2-x1), np.full(n,y1)]),
        np.column_stack([np.full(n,x2), y1+t*(y2-y1)]),
        np.column_stack([x2-t*(x2-x1), np.full(n,y2)]),
        np.column_stack([np.full(n,x1), y2-t*(y2-y1)]),
    ])


def hd95_case(gt_bboxes: List, pred_bboxes: List, pct: float=95.0) -> float:
    A_pts=[_bbox_pts(b) for b in gt_bboxes   if b]
    B_pts=[_bbox_pts(b) for b in pred_bboxes if b]
    if not A_pts or not B_pts: return float("nan")
    A=np.vstack(A_pts); B=np.vstack(B_pts)
    d_ab=cdist(A,B).min(axis=1); d_ba=cdist(B,A).min(axis=1)
    return float(np.percentile(np.concatenate([d_ab,d_ba]),pct))


# ── DATA LOADING ─────────────────────────────────────────────

def load_test_json(path: Path) -> List[dict]:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def load_predictions(path: Path) -> Dict[str, dict]:
    """Load prediction JSON → {sample_id: pred_dict}."""
    with open(path, encoding="utf-8") as f:
        preds = json.load(f)
    return {p["id"]: p for p in preds}


def make_mock_predictions(
    test_data: List[dict],
    noise_px:  int   = 15,
    lat_acc:   float = 0.95,
    pres_acc:  float = 0.80,   # FIX: mock giờ có presence errors
    seed:      int   = SEED,
) -> Dict[str, dict]:
    """Mock predictions với noise. FIX: presence không copy GT nữa."""
    rng = random.Random(seed)
    preds = {}

    for s in test_data:
        meta    = s["metadata"]
        gt_bbox = parse_bbox_norm(meta.get("bbox_z_norm"))
        gt_lat  = meta.get("laterality", "unknown")
        gt_pm   = meta.get("presence_minus_label", "no")
        gt_pp   = meta.get("presence_plus_label",  "no")

        # Bbox with noise
        if gt_bbox:
            def n(): return int(rng.gauss(0, noise_px))
            pb=[max(0,gt_bbox[0]+n()),max(0,gt_bbox[1]+n()),
                min(IMG_SIZE,gt_bbox[2]+n()),min(IMG_SIZE,gt_bbox[3]+n())]
            if pb[2]<=pb[0]: pb[2]=pb[0]+1
            if pb[3]<=pb[1]: pb[3]=pb[1]+1
            bbox_str=f"<|box_start|>({pb[0]},{pb[1]}),({pb[2]},{pb[3]})<|box_end|>"
        else:
            pb=None; bbox_str=""

        # Laterality with noise
        pred_lat = gt_lat if rng.random()<lat_acc else ("right" if gt_lat=="left" else "left")

        # FIX: Presence với noise (không copy GT)
        pred_pm = gt_pm if rng.random()<pres_acc else ("yes" if gt_pm=="no" else "no")
        pred_pp = gt_pp if rng.random()<pres_acc else ("yes" if gt_pp=="no" else "no")
        pm_str  = "present" if pred_pm=="yes" else "not present"
        pp_str  = "present" if pred_pp=="yes" else "not present"

        pred_a1 = f"The kidney is visible on the {pred_lat} side."
        pred_a2 = (
            f"Center slice bounding box: {bbox_str}. "
            f"Previous slice (z-{meta.get('k',1)}): kidney {pm_str}. "
            f"Next slice (z+{meta.get('k',1)}): kidney {pp_str}."
        )

        preds[s["id"]] = {
            "id": s["id"],
            "pred_a1": pred_a1,
            "pred_a2": pred_a2,
        }
    return preds


# ── CORE EVALUATOR ───────────────────────────────────────────

def evaluate_checkpoint(
    ckpt_name:   str,
    test_data:   List[dict],
    preds:       Dict[str, dict],
    bootstrap_n: int  = BOOTSTRAP_N,
    seed:        int  = SEED,
) -> Tuple[dict, List[dict]]:
    """
    Compute all 5 metrics + presence accuracy.
    FIX 1: presence parsed từ raw pred_a2 text.
    FIX 2: laterality regression flag thêm vào per_sample.
    """
    per_sample = []
    iou_list=[]; dist_list=[]; lat_list=[]
    pres_m_list=[]; pres_p_list=[]   # FIX 1: presence accuracy lists
    pres_missing_m=0; pres_missing_p=0

    case_gt   = collections.defaultdict(dict)
    case_pred = collections.defaultdict(dict)
    case_k    = collections.defaultdict(dict)

    for s in test_data:
        sid=s["id"]; meta=s["metadata"]
        gt_bbox = parse_bbox_norm(meta.get("bbox_z_norm"))
        gt_lat  = meta.get("laterality", "unknown")
        gt_pm   = meta.get("presence_minus_label", "no")
        gt_pp   = meta.get("presence_plus_label",  "no")
        case_id = meta["case_id"]
        slice_z = meta["slice_id_z"]
        k       = meta["k"]

        pred     = preds.get(sid, {})
        pred_a1  = pred.get("pred_a1", "")
        pred_a2  = pred.get("pred_a2", "")

        # Bbox
        pred_bbox = pred.get("pred_bbox")
        if pred_bbox is None:
            pred_bbox = parse_bbox_pixel(pred_a2)

        # Laterality
        pred_lat = pred.get("pred_laterality") or parse_laterality(pred_a1)

        # FIX 1: Presence — parse từ pred_a2 raw text
        pred_pm = parse_presence(pred_a2, PAT_PRES_MINUS)
        pred_pp = parse_presence(pred_a2, PAT_PRES_PLUS)

        if pred_pm is None:
            pres_missing_m += 1
            pred_pm = "no"   # fallback conservative
        if pred_pp is None:
            pres_missing_p += 1
            pred_pp = "no"

        pres_m_list.append(int(pred_pm == gt_pm))
        pres_p_list.append(int(pred_pp == gt_pp))

        # 2D IoU
        iou  = iou_2d(gt_bbox, pred_bbox)
        iou_list.append(iou)

        # Center distance
        dist = center_dist_px(gt_bbox, pred_bbox)
        if not math.isnan(dist): dist_list.append(dist)

        # Laterality
        lat_ok = None
        if gt_lat in ("left","right"):
            lat_ok = int(pred_lat == gt_lat)
            lat_list.append(lat_ok)

        # FIX 2: Laterality regression flag
        # Khi IoU cao (bbox đúng) nhưng laterality sai → likely left↔right confusion
        lat_regression = (
            lat_ok == 0 and iou >= 0.3
        )

        # 3D accumulation (dedup by smallest k)
        if k < case_k[case_id].get(slice_z, 999):
            case_k[case_id][slice_z]   = k
            case_gt[case_id][slice_z]  = gt_bbox
            case_pred[case_id][slice_z] = pred_bbox

        per_sample.append({
            "id": sid, "ckpt": ckpt_name,
            "case_id": case_id, "slice_id_z": slice_z, "k": k,
            "task_idx": meta.get("task_idx"),
            # Ground truth
            "gt_bbox":   gt_bbox, "gt_lateral": gt_lat,
            "gt_pres_minus": gt_pm, "gt_pres_plus": gt_pp,
            # Predictions
            "pred_bbox":   pred_bbox, "pred_lateral": pred_lat,
            "pred_pres_minus": pred_pm, "pred_pres_plus": pred_pp,
            # Per-sample metrics
            "iou_2d":         round(iou, 4),
            "center_dist_px": round(dist,2) if not math.isnan(dist) else None,
            "lat_correct":    lat_ok,
            # FIX 2: regression flag
            "lat_regression_flag": lat_regression,  # bbox OK but lat wrong
            # FIX 1: presence correct
            "pres_minus_correct": int(pred_pm == gt_pm),
            "pres_plus_correct":  int(pred_pp == gt_pp),
        })

    # ── Aggregate 2D ──
    mean_iou  = float(np.mean(iou_list))  if iou_list  else float("nan")
    ci_lo, ci_hi = bootstrap_ci(iou_list, n=bootstrap_n, seed=seed)
    mean_dist = float(np.mean(dist_list)) if dist_list else float("nan")
    lat_acc   = float(np.mean(lat_list))  if lat_list  else float("nan")

    # FIX 1: Presence accuracy
    pres_acc_minus = float(np.mean(pres_m_list)) if pres_m_list else float("nan")
    pres_acc_plus  = float(np.mean(pres_p_list)) if pres_p_list else float("nan")

    # FIX 2: Laterality regression count
    lat_regression_count = sum(1 for s in per_sample if s.get("lat_regression_flag"))

    # ── 3D per-case ──
    viou_list=[]; hd95_list=[]; case_3d={}
    for cid, gt_map in case_gt.items():
        pred_map = case_pred[cid]
        vv = viou_3d(gt_map, pred_map); viou_list.append(vv)
        sorted_z = sorted(gt_map)
        hd = hd95_case([gt_map.get(z) for z in sorted_z],
                       [pred_map.get(z) for z in sorted_z])
        hd95_list.append(hd)
        case_3d[cid] = {"viou_3d": round(vv,4),
                        "hd95_px": round(hd,2) if not math.isnan(hd) else None}

    seen=set()
    for rec in per_sample:
        if rec["case_id"] not in seen:
            rec.update(case_3d.get(rec["case_id"], {}))
            seen.add(rec["case_id"])

    mean_viou = float(np.mean(viou_list))  if viou_list else float("nan")
    hd_clean  = [h for h in hd95_list if not math.isnan(h)]
    mean_hd95 = float(np.mean(hd_clean)) if hd_clean else float("nan")
    std_hd95  = float(np.std(hd_clean))  if hd_clean else float("nan")

    summary = {
        "ckpt":               ckpt_name,
        "n_samples":          len(test_data),
        "n_cases":            len(case_gt),
        # Metric 1
        "mean_iou_2d":        round(mean_iou,  4),
        "iou_2d_ci_lo":       round(ci_lo,     4),
        "iou_2d_ci_hi":       round(ci_hi,     4),
        # Metric 2
        "avg_center_dist_px": round(mean_dist, 2),
        # Metric 3
        "laterality_acc":     round(lat_acc,   4),
        "lat_regression_n":   lat_regression_count,   # FIX 2
        # Metric 4 (PRIMARY)
        "mean_viou_3d":       round(mean_viou, 4),
        # Metric 5
        "mean_hd95_px":       round(mean_hd95, 2),
        "std_hd95_px":        round(std_hd95,  2),
        # FIX 1: Presence accuracy
        "pres_acc_minus":     round(pres_acc_minus, 4),
        "pres_acc_plus":      round(pres_acc_plus,  4),
        "pres_missing_minus": pres_missing_m,
        "pres_missing_plus":  pres_missing_p,
    }
    return summary, per_sample


# ── PARALLEL RUNNER ──────────────────────────────────────────

def _worker_fn(args):
    test_data, pred_path, ckpt_name, mock, noise_px, bootstrap_n, seed = args
    try:
        if mock:
            preds = make_mock_predictions(test_data, noise_px=noise_px, seed=seed)
        else:
            preds = load_predictions(Path(pred_path))
        summary, per_sample = evaluate_checkpoint(
            ckpt_name, test_data, preds, bootstrap_n=bootstrap_n, seed=seed
        )
        return ckpt_name, summary, per_sample, None
    except Exception:
        import traceback
        return ckpt_name, None, None, traceback.format_exc()


def run_parallel(test_data, ckpt_jobs, n_workers=1, bootstrap_n=BOOTSTRAP_N,
                 noise_px=15, seed=SEED):
    worker_args = [
        (test_data, pred_path, ckpt_name, mock, noise_px, bootstrap_n, seed)
        for pred_path, ckpt_name, mock in ckpt_jobs
    ]
    if n_workers>1 and len(worker_args)>1:
        with multiprocessing.Pool(min(n_workers,len(worker_args))) as pool:
            return pool.map(_worker_fn, worker_args)
    return [_worker_fn(a) for a in worker_args]


# ── OUTPUT ───────────────────────────────────────────────────

CSV_FIELDS = [
    "ckpt","n_samples","n_cases",
    "mean_iou_2d","iou_2d_ci_lo","iou_2d_ci_hi",
    "avg_center_dist_px","laterality_acc","lat_regression_n",
    "mean_viou_3d",
    "mean_hd95_px","std_hd95_px",
    "pres_acc_minus","pres_acc_plus",
    "pres_missing_minus","pres_missing_plus",
]


def save_eval_table(summaries: List[dict], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "eval_table.csv"
    with open(path,"w",newline="",encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_FIELDS, extrasaction="ignore")
        w.writeheader(); w.writerows(summaries)
    print(f"  -> {path}  ({len(summaries)} rows)")


def save_per_sample(per_sample: List[dict], output_dir: Path, ckpt_name: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / f"per_sample_{ckpt_name}.json"
    with open(path,"w",encoding="utf-8") as f:
        json.dump(per_sample, f, ensure_ascii=False, indent=2)
    mb = os.path.getsize(path)/1e6
    print(f"  -> {path}  ({len(per_sample):,} records, {mb:.1f} MB)")


def print_results_table(summaries: List[dict]) -> None:
    print()
    h = (f"{'Checkpoint':<18} {'mIoU2D':>8} {'95%CI':>16} {'CentDist':>9} "
         f"{'LatAcc':>7} {'LatReg':>7} {'vIoU3D':>8} {'HD95':>7} "
         f"{'PAccM':>7} {'PAccP':>7}")
    print(h); print("─"*len(h))
    for s in summaries:
        ci = f"[{s['iou_2d_ci_lo']:.3f},{s['iou_2d_ci_hi']:.3f}]"
        print(
            f"{s['ckpt']:<18} {s['mean_iou_2d']:>8.4f} {ci:>16} "
            f"{s['avg_center_dist_px']:>9.2f} "
            f"{s['laterality_acc']:>7.4f} {s['lat_regression_n']:>7} "
            f"{s['mean_viou_3d']:>8.4f} {s['mean_hd95_px']:>7.2f} "
            f"{s['pres_acc_minus']:>7.4f} {s['pres_acc_plus']:>7.4f}"
        )
    print()


# ── MAIN ─────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="TriScaTell Eval Pipeline v2")
    parser.add_argument("--test_json",   required=True)
    parser.add_argument("--pred_jsons",  nargs="+", default=None)
    parser.add_argument("--ckpt_names",  nargs="+", default=None)
    parser.add_argument("--output_dir",  default="results")
    parser.add_argument("--workers",     type=int,   default=1)
    parser.add_argument("--mock",        action="store_true")
    parser.add_argument("--mock_noise",  type=int,   default=15)
    parser.add_argument("--bootstrap_n", type=int,   default=BOOTSTRAP_N)
    parser.add_argument("--seed",        type=int,   default=SEED)
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    print("="*65)
    print("  TriScaTell Evaluation Pipeline v2 (fixed)")
    print("="*65)

    test_data = load_test_json(Path(args.test_json))
    n_cases   = len(set(s["metadata"]["case_id"] for s in test_data))
    print(f"\nLoaded: {len(test_data):,} samples | {n_cases} cases")

    if args.mock:
        jobs = [(None, f"mock_noise{args.mock_noise}", True)]
    elif args.pred_jsons:
        names = args.ckpt_names or [f"ckpt{i+1}" for i in range(len(args.pred_jsons))]
        jobs  = [(p,n,False) for p,n in zip(args.pred_jsons, names)]
    else:
        print("[WARN] No --pred_jsons. Using --mock.")
        jobs = [(None,"mock",True)]

    print(f"Jobs: {[j[1] for j in jobs]} | workers={args.workers}")
    t0 = time.time()

    results = run_parallel(test_data, jobs, n_workers=args.workers,
                           bootstrap_n=args.bootstrap_n,
                           noise_px=args.mock_noise, seed=args.seed)

    summaries=[]
    for ckpt_name, summary, per_sample, err in results:
        if err: print(f"\n[ERROR] {ckpt_name}:\n{err}"); continue
        summaries.append(summary)
        print(f"\n[{ckpt_name}]")
        for k in CSV_FIELDS[3:]:
            print(f"  {k:<25}: {summary[k]}")

    print_results_table(summaries)
    print("── Saving ──")
    save_eval_table(summaries, out_dir)
    for ckpt_name, summary, per_sample, err in results:
        if per_sample:
            save_per_sample(per_sample, out_dir, ckpt_name)

    print(f"\n✓ Done in {time.time()-t0:.1f}s  →  {out_dir}/")
    print("="*65)


if __name__ == "__main__":
    main()
